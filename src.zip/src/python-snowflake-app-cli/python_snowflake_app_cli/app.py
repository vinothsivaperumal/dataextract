import logging
import os
import socket
import re
import getopt
import sys
import csv
import traceback
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
import json
import toml
import snowflake.connector
from openpyxl import load_workbook
from pdfrw import PdfWriter
import pdfkit
from mod.utils import Utils
from mod.snow import Snow
from datetime import datetime,date
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, KeepTogether
import tempfile as tf
from pathlib import Path 
import matplotlib.pyplot as plt
from mod.mackay_s3 import MackayS3


ffi_lib_path = os.path.dirname(os.path.dirname(__file__)) if '.pyz' in str(os.path.dirname(__file__)) else os.path.dirname(__file__)
sys.path.append(ffi_lib_path)
business_date_key= "$BUSINESS_DATE"

class Invalidextract(Exception):
    pass 
class MissingExtract(Exception):
    pass
class UnsupportedFileFormat(Exception):
    pass 

class App:
    """Class Name and Description here"""
    program_name = os.path.basename(__file__)
    version = 1.0
    hostname = socket.gethostname()
    args_patt = re.compile(".*:.*")
    root_file_obj = __name__
    root_package_obj = __file__
    root_directory = os.path.dirname(__file__)
    logging.basicConfig(level="INFO", format="[BaseConfig] %(asctime)s - <PID %(process)d:%(processName)s> - %(pathname)s:%(lineno)d - %(funcName)s:%(lineno)d - %(name)s - %(levelname)s: %(message)s")
    __app_config  = {}
    daydate=None
    
    
    def main(self):
        """Main function description here"""
        
        logging.info(f"Adding Root Directory to PATH: {os.path.join(self.root_directory)}")
        sys.path.append(os.path.join(self.root_directory))
        logging.info("Starting App:.....")
        logging.info('SysPaths:\n'.join(sys.path))
        logging.info(f"Current Working DIR: {os.getcwd()}")

        # Process Command Line Arguments        
        try:
            (opts, args) = getopt.getopt(
                sys.argv[1:],
                "",
                [
                    "help",
                    "env=",
                    "extract-name=",
                    "output-directory=",
                    "output-format=",
                    "output-filename=",
                    "business-date=",
                    "day-date=",
                    "yyyymmdd="
                ]
            )
            utl = Utils(
                program_name=self.program_name
                , root_file_obj=self.root_file_obj
                , root_package_obj=self.root_package_obj
                , root_directory=self.root_directory
            )
            utl.parse_args(opts=opts, args=args)
            utl.set_app_config()
            self.__app_config = utl.get_app_config()
            logging.info(self.__app_config)
            app_parameters = utl.get_cli_application_parameters()
            logging.info(f"Application Parameters: {app_parameters}")

            snow_config = self.__app_config.get("datasource").get("snowflake").get("prism")
            logging.info("Snow Config: {}".format(snow_config))
            aws_config = self.__app_config.get("AmazonS3")
            logging.info("AWS Config: {}".format(aws_config))
            sn = Snow(
                **snow_config
            )
            cursor = sn.conn.cursor()
        
            # print(opts)

            match_extract_name = None

            for key,value in opts:
                if key in '--extract-name':
                    match_extract_name = key

            # print(match_extract_name)
            for key in ['business-date','day-date','yyyymmdd','output-format','output-directory','output-filename']:
                if key not in app_parameters:
                    app_parameters[key]=None
            # print(app_parameters)

            if match_extract_name is None:
                raise MissingExtract("Missing Extract. Please enter --extract-name <> in command line.")
            else:
                res = validate_extract(cursor, app_parameters.get('extract-name'))
            
            print(f"Result :{res}")
            
            if app_parameters.get('business-date') is None:
                """Assigns default business date if not overridden"""    
                BUSINESS_DATE = str(get_business_date(cursor))
                app_parameters[business_date_key] = BUSINESS_DATE
            else:
                BUSINESS_DATE = app_parameters.get('business-date')
                app_parameters[business_date_key] = datetime.strptime(BUSINESS_DATE, '%Y%m%d').strftime('%Y-%m-%d');
            
            if app_parameters.get('day-date') is None:
                """Assigns default as business date if not overridden- to pass as param for get_alldates()"""   
                daydate = app_parameters.get(business_date_key)
            else:
                daydate = datetime.strptime(app_parameters.get('day-date'), '%Y%m%d').strftime('%Y-%m-%d')
            
            

            all_dates = get_alldates(cursor,daydate)
            PREV_BUSINESS_DATE,PREV_MONTH_END,SYS_DATE,CURR_MONTH_END,PREV_CAL_MONTH_END,CURR_CAL_MONTH_END,CURR_MONTH_START,CURR_CAL_MONTH_START = [all_dates[i] for i in range(len(all_dates))]
            
            app_parameters['$PREV_BUSINESS_DATE'] = datetime.strftime(PREV_BUSINESS_DATE,'%Y-%m-%d');
            app_parameters['$PREV_MONTH_END'] = datetime.strftime(PREV_MONTH_END,'%Y-%m-%d');
            app_parameters['$SYS_DATE'] = datetime.strftime(SYS_DATE,'%Y-%m-%d');
            app_parameters['$CURR_MONTH_END'] = datetime.strftime(CURR_MONTH_END,'%Y-%m-%d');
            app_parameters['$PREV_CAL_MONTH_END'] = datetime.strftime(PREV_CAL_MONTH_END,'%Y-%m-%d');
            app_parameters['$CURR_CAL_MONTH_END'] = datetime.strftime(CURR_CAL_MONTH_END,'%Y-%m-%d');
            app_parameters['$CURR_MONTH_START'] = datetime.strftime(CURR_MONTH_START,'%Y-%m-%d');
            app_parameters['$CURR_CAL_MONTH_START'] = datetime.strftime(CURR_CAL_MONTH_START,'%Y-%m-%d');
            """To be used as dynamic param values while query excution """
            app_parameters['FOLDER'] = res[10];
            app_parameters['USE_PARTITIONS'] = f"{res[11]}";
            
            if app_parameters.get('yyyymmdd') is None:
                """Assigns default system date if not overridden"""
                app_parameters['${YYYY-MM-DD}'] = str(date.today());
            else:
                app_parameters['${YYYY-MM-DD}'] = datetime.strptime(app_parameters.get('yyyymmdd'), '%Y%m%d').strftime('%Y-%m-%d');
            
            if app_parameters.get('output-format') is None and res is not None:
                """Assigns default folder location from table-column 'FOLDER' if not overriden"""
                app_parameters['output-format'] = re.search(r'TYPE\s*=\s*([A-Za-z]+)', res[5]).group(1)

            if app_parameters.get('output-directory') is None and res is not None:
                """Assigns default folder location from table-column 'FOLDER' if not overriden"""
                app_parameters['output-directory'] = res[10]

            if app_parameters.get('output-filename') is None and res is not None:
                """Assigns default Filename to save from table-column 'FILE_NAME' if not overriden"""
                app_parameters['output-filename'] = res[12]
                
            
            if res is None:
                raise Invalidextract("Invalid input, no such Extract exists")
            elif res is not None and res[3] is None:
                if res[4] is None:
                    query = f"select * from {res[2]}"
                else:
                    query = f"select {res[4]} from {res[2]}"
            else:
                if res[4] is None:
                    query = f"select * from {res[2]} where {res[3]}"
                else: 
                    query = f"select {res[4]} from {res[2]} where {res[3]}" 

            
            query = get_replace_param_value(cursor,query,app_parameters)


            for key,value in app_parameters.items():
                """Replaces the dynamic param with values. '$BUSINESS_DATE' replaces with '2024-03-05' if assigned"""
                if value is not None:
                    query=query.replace(key,value)

            if app_parameters.get('output-directory') is not None and res is not None:
                for key,value in app_parameters.items():
                    # print(value)
                    if value is not None:
                        app_parameters['output-directory'] = app_parameters.get('output-directory').replace(key,value)
            
            logging.info("output-directory")

            if app_parameters.get('output-filename') is not None and res is not None:
                app_parameters['output-filename'] = get_replace_param_value(cursor,app_parameters.get('output-filename'),app_parameters)
                for key,value in app_parameters.items():
                    if value is not None:
                        app_parameters['output-filename'] = re.sub(r'\..*','',app_parameters.get('output-filename').replace(key,value))

            logging.info("output-directory")

            logging.info("FOLDER")
            
            if app_parameters.get('FOLDER') is not None and res is not None:
                for key,value in app_parameters.items():
                    if value is not None and key in app_parameters.get('FOLDER'):
                        app_parameters['FOLDER'] = re.sub(r'\..*','',app_parameters.get('FOLDER').replace(key,value))
           
            logging.info(f"app_parameters : {app_parameters}")

            if app_parameters.get('output-filename') is not None and res is not None:
                for key1,value1 in app_parameters.items():
                    if key1 == 'output-filename' and value1 is not None:
                        out_filename = app_parameters.get('output-filename') 
                        fourth_group = None                       
                        pattern = r'YYYYMMDD_HHmmSSFF3'
                        matches = re.search(pattern,out_filename)
                        
                        print(matches)

                        if matches:
                           fourth_group = matches.group(0) 
                        print(fourth_group)

                        if fourth_group == 'YYYYMMDD_HHmmSSFF3':
                            # Replace the matched part with the formatted date and time
                            app_parameters['output-filename'] = re.sub(pattern, datetime.now().strftime("%Y%m%d_%H%M%S%f")[:-3], out_filename).replace("${","").replace("}","").replace("|","")
            
            logging.info("Generating the Query:.....")
            print(f"\n SQL Query for given extract: \n {query}")
            """Dynamically generated Query to be execute for valid Extract"""
            # print(app_parameters.get('output-filename'))

            logging.info("Executing the Query:.....")
            # print(app_parameters)
            cursor.execute(query)
            result = cursor.fetchall()
            if not result:
                print("Result is empty. Cannot export.")
            # print(re.sub(r'\..*','',app_parameters.get('output-filename')))
            if app_parameters.get('output-format')in ['XLSX', 'xlsx']:
                makexlsx(aws_config,cursor, result, app_parameters)
            elif app_parameters.get('output-format')in ['PDF', 'pdf']:     
                makepdf(aws_config,cursor, result, app_parameters)
            elif app_parameters.get('output-format')in ['HTML', 'html']:     
                makehtml(aws_config,cursor, result, app_parameters)
            elif app_parameters.get('output-format')in ['CSV', 'csv']:  
                logging.info("AWS Config: {}".format(aws_config))  
                makecsv(aws_config,cursor, result, app_parameters)
            else:
                raise UnsupportedFileFormat("Unsupported Output Format entered. Export only as XLSX/PDF/HTML/CSV")


            # insertinto_extract_log(cursor, app_parameters)

            logging.info("Execution done and Exporting the Extract:.....")
           
            logging.info("Extract Exported successfully:.....")
            insertinto_extract_log(cursor,query, app_parameters)
            logging.info("Logged the entry successfully:.....")
            logging.info("Shutting down App:.....")

        except ConnectionError:
            exc_type, exc_value, exec_traceback = sys.exc_info()
            logging.error(f"ConnectionError occurred: f{str(exc_type)}")
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name="ERROR MESSAGE"
            )
            sys.exit(255)
        except MissingExtract: 
            exc_type, exc_value, exec_traceback = sys.exc_info()            
            logging.error(f"{exc_value}")            
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name=f"{exc_value}"
            )
            sys.exit(255) 
        except UnsupportedFileFormat: 
            exc_type, exc_value, exec_traceback = sys.exc_info()            
            logging.error(f"{exc_value}")            
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name=f"{exc_value}"
            )
            sys.exit(255)        
        except Invalidextract: 
            exc_type, exc_value, exec_traceback = sys.exc_info()            
            logging.error(f"{exc_value}")            
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name="ERROR MESSAGE"
            )
            sys.exit(255)
        except IOError:
            exc_type, exc_value, exec_traceback = sys.exc_info()
            logging.error(f"IOError occurred: f{str(exc_type)}")
            logging.error(f"IOError occurred: f{str(exc_value)}")
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name="ERROR MESSAGE "
            )
            sys.exit(255)            
        except Exception:
            exc_type, exc_value, exec_traceback = sys.exc_info()
            logging.error(f"Unknown Exception or Error occurred: f{str(exc_type)}")
            self.log_pretty(
                input_data=traceback.format_exception(
                    exc_type,
                    exc_value,
                    exec_traceback
                ),
                log_level="debug",
                data_name="ERROR MESSAGE "
            )
            sys.exit(255)

        #except UnsupportedFileFormat:
         #   def __init__(self, file_format):
          #      self.file_format = file_format
           #     super().__init__(f"Unsupported format: {file_format}. Only XLSX, PDF, and CSV formats are supported.")
       
        logging.info("Shutting down App:.....")
    
    def log_pretty(
            self,
            input_data,
            log_level="debug",
            data_name=None
    ) -> None:
        """
        TODO: update this Method documentation
        :param input_data:
        :param log_level:
        :param data_name:
        :return:
        """
        p_input: str = f""""
------------------------------------------ [LogPretty] [{data_name}] [Start] ----------------------------------------
{json.dumps(input_data, indent=4)}
------------------------------------------ [LogPretty] [{data_name}] [End] ------------------------------------------
"""
        if log_level == "info":
            logging.info(p_input)
        elif log_level == "error":
            logging.error(p_input)
        elif log_level == "debug":
            logging.debug(p_input)
        elif log_level == "warning":
            logging.warning(p_input)
        elif log_level == "critical":
            logging.critical(p_input)
        else:
            logging.info(p_input)




if os.environ.get('APP_ENVIRONMENT') is None:
    a = 'local'
else:
    a = os.environ.get('APP_ENVIRONMENT')

print(f"Env Variable: APP_ENVIRONMENT: {a}")
""" read Env variable: APP_ENVIRONMENT"""

def validate_extract(cur, extract_name):
    """Validates the Extract existence"""
    cur.execute(f"select * from SC_EXTRACT.DB_EXTRACT_CONFIG where extract_name = '{extract_name}'")
    res = cur.fetchone()
    return res


def get_business_date(cur):
    """Assigns the default system business date if not overridden"""
    quer1 = "CALL sc_load.sp_get_Prism_Business_Date()"
    cur.execute(quer1)
    bus_date = cur.fetchone()
    res = bus_date[0]
    return res

def get_alldates(cur,daydate):
    """Assigns dynamic params dates based on daydate """
    quer2 = f"SELECT PREV_BUS_DAY_DATE,PREV_END_OF_BUSINESS_MONTH,convert_timezone('EST',getdate()) AS SYS_DATE,NEXT_END_OF_BUSINESS_MONTH,PREV_END_OF_MONTH,NEXT_END_OF_MONTH,PREV_START_OF_BUSINESS_MONTH,DATEADD(day, 1, PREV_END_OF_MONTH) FROM SC_LOAD.T_DATE WHERE DAY_DATE = '{daydate}' AND BUSINESS_CALENDAR_CODE='NYSE'"
    cur.execute(quer2)
    all_dates = cur.fetchone()
    return all_dates

def insertinto_extract_log(cur,query,app_parameters):
    """Execute insert query here"""
    file_extn = app_parameters.get('output-format')
    if app_parameters.get('output-directory').endswith("/"):
        extract_location = f"{app_parameters.get('output-directory')}{app_parameters.get('output-filename')}.{file_extn.lower()}"
    else:
        extract_location = f"{app_parameters.get('output-directory')}/{app_parameters.get('output-filename')}.{file_extn.lower()}"
    
    print(extract_location)
    print(f"Query before update:{query}")
    query = replace_date_format(query)
    print(f"\nQuery after update:{query}")

    quer3 = f"INSERT INTO SC_EXTRACT.DB_EXTRACT_LOG (EXTRACT_NAME, EXTRACT_SQL, BUSINESS_DATE, EXTRACT_LOCATION,LAST_RUN_TIME, ACTIVE_FL) VALUES ('{app_parameters.get('extract-name')}', '{query}', '{app_parameters.get('$BUSINESS_DATE')}','{extract_location}','{datetime.now()}','TRUE')"
    quer4 = f"UPDATE sc_extract.db_extract_log SET ACTIVE_FL = 'FALSE' WHERE EXTRACT_NAME = '{app_parameters.get('extract-name')}' AND BUSINESS_DATE = '{app_parameters.get('$BUSINESS_DATE')}'"
    try:
        # Start a transaction
        cur.execute("BEGIN TRANSACTION")
        # Execute both queries
        cur.execute(quer4)
        # Commit the transaction
        cur.execute("COMMIT")
        cur.execute(quer3)
    except Exception as e:
        # Rollback the transaction if an error occurs
        cur.execute("ROLLBACK")
        print("Error occurred:", e)


def replace_date_format(query):
    # Regular expression pattern to match dates in the format '%Y-%m-%d'
    date_pattern = r'\b\d{4}-\d{2}-\d{2}\b'
    # Replace matched dates with quoted dates
    replaced_query = re.sub(date_pattern, lambda x: f"'{x.group(0)}'", query)
    return replaced_query


def get_replace_param_value(cur,str_value, app_parameters):

    has_matches = False
    cust_date_pattern = r'\$\{([^|]+)\|([^|]+)\|([^|]+)\|([^|]+)\}'
    matches = re.finditer(cust_date_pattern,str_value)
    replace_value = str_value 
    for match in matches:
        has_matches = True
        split_values =[values.split("|") for values in match.groups()] 
        param_value = app_parameters.get(split_values[0][0]) 
        day_to_add = int(split_values[1][0])
        date_zone = split_values[2][0]
        _value = datetime.strptime(param_value,'%Y-%m-%d')
        quer1 = "sc_load.sp_add_business_days"
        cur.callproc(quer1,[_value,day_to_add,date_zone])
        bus_date = cur.fetchone()[0]        
        replace_value = replace_value.replace(match.group(),bus_date.strftime('%Y-%m-%d'))
    
    if has_matches:
        return replace_value
    else:
        return str_value

def makexlsx(aws_config,cur, result, app_parameters):
    """Exports the Excel output file to location"""
    extract_name = re.sub(r'\..*','',app_parameters.get('output-filename'))
    file_extn = app_parameters.get('output-format')
    folder_path = app_parameters.get('FOLDER')
    use_partitions =app_parameters.get('USE_PARTITIONS')
    business_date = app_parameters.get(business_date_key)
    # print(result)
    df = pd.DataFrame(result, columns=[desc[0] for desc in cur.description])
    filename =extract_name+"."+file_extn.lower()
    with tf.NamedTemporaryFile(suffix='.xlsx',delete=False) as tempfile:
        df.to_excel(tempfile.name, index=False)
        MackayS3.s3_upload(aws_config,tempfile.name,filename,folder_path,use_partitions,business_date)
    

def makehtml(aws_config,cur, result, app_parameters):
    """Exports the HTML output file to location"""
    extract_name = re.sub(r'\..*','',app_parameters.get('output-filename'))
    file_extn = app_parameters.get('output-format') 
    folder_path = app_parameters.get('FOLDER')
    use_partitions =app_parameters.get('USE_PARTITIONS')
    business_date = app_parameters.get(business_date_key)
    filename =extract_name+"."+file_extn.lower()
    # print(result)
    with tf.NamedTemporaryFile(suffix='.xlsx',delete=False) as tempfile:
        temple_xlsx_file_path = tempfile.name
        df = pd.DataFrame(result,columns=[desc[0] for desc in cur.description])
        df.to_excel(temple_xlsx_file_path,index=False)
        df_read = pd.read_excel(temple_xlsx_file_path)
        with tf.NamedTemporaryFile(suffix='.html',delete=False) as temphtmlfile:
            df_read.to_html(temphtmlfile.name) # Export the DataFrame (Excel doc) to an html file 
            MackayS3.s3_upload(aws_config,temphtmlfile.name,filename,folder_path,use_partitions,business_date)
    
def makepdf(aws_config,cur, result, app_parameters):
    """Exports the PDF output file to location"""
    extract_name = re.sub(r'\..*','',app_parameters.get('output-filename'))
    file_extn = app_parameters.get('output-format') 
    folder_path = app_parameters.get('FOLDER')
    use_partitions =app_parameters.get('USE_PARTITIONS')
    business_date = app_parameters.get(business_date_key) 
    filename =extract_name+"."+file_extn.lower()
    # print(result)
    with tf.NamedTemporaryFile(suffix='.xlsx',delete=False) as tempfile:
        temple_xlsx_file_path = tempfile.name
        df = pd.DataFrame(result,columns=[desc[0] for desc in cur.description])
        df.to_excel(temple_xlsx_file_path,index=False)
        df_read = pd.read_excel(temple_xlsx_file_path)
        num_rows,num_cols = df_read.shape
        fig_width = num_cols * 0.25 
        fig_height = num_rows * 0.25
        # Plot DataFrame
        _, ax = plt.subplots(figsize=(fig_width,fig_height))
        #ax.axis('tight')
        ax.axis('off')    
        tables=ax.table(cellText=df_read.values, colLabels=df_read.columns, loc='center')
        tables.auto_set_font_size(False)
        tables.set_fontsize(10)
        tables.auto_set_column_width(col=list(range(num_cols)))
        tables.set_fontsize(10)
        # Save plot as PDF
        with tf.NamedTemporaryFile(suffix='.pdf',delete=False) as temppdffile:
            plt.savefig(temppdffile.name, format='pdf', bbox_inches='tight')
            plt.close()
        MackayS3.s3_upload(aws_config,temppdffile.name,filename,folder_path,use_partitions,business_date)                         
        
def makecsv(aws_config,cur, result, app_parameters):
    """Exports the CSV output file to location"""
    extract_name = re.sub(r'\..*','',app_parameters.get('output-filename'))
    file_extn = app_parameters.get('output-format') 
    folder_path = app_parameters.get('FOLDER')
    use_partitions =app_parameters.get('USE_PARTITIONS')
    business_date = app_parameters.get(business_date_key)   
    filename =extract_name+"."+file_extn.lower()
    file_path_csv = f'C:\\Users\\sseepana\\source\\repos\\python\\{filename}'
    file_path = os.path.realpath(file_path_csv)
    with open(file_path_csv, 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow([desc[0] for desc in cur.description])
        csvwriter.writerows(result)
    MackayS3.s3_upload(aws_config,file_path,filename,folder_path,use_partitions,business_date)

if __name__ == "__main__":
    App().main()
class MackayNas:
    def __init__(self) -> None:
        """__init__.
        """
        pass

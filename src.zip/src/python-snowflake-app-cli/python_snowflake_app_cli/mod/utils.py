import os
import platform
from datetime import datetime
import logging
import logging.config
import re
import sys
from pathlib import Path as Pth
import pkg_resources
import toml
import yaml
import socket


class Utils:
    """Utils: Basic Utils class for application"""

    logger = logging.getLogger()
    _is_pyz = False
    _hostname = socket.gethostname()
    env_override = None
    _toml_config = None
    _app_config: dict

    _program_name = None
    _root_file_obj = None
    _root_package_obj = None
    _root_directory = None

    _lconfig = None
    cli_application_parameters = {}
    
    # Env Lookup Setup
    _env_lookup = {
        "dev",
        "qa",
        "uat",
        "prod"
    }

    def __init__(
        self,
        program_name,
        root_file_obj,
        root_package_obj,
        root_directory
    ):
        """Initialize"""
        self._program_name = program_name
        self._root_file_obj = root_file_obj
        self._root_package_obj = root_package_obj
        self._root_directory = root_directory
        # Check if .pyz package
        if re.search(".pyz", str(sys.argv[0])):
            self._is_pyz = True

    def is_pyz(self) -> bool:
        """Check is app is pyz"""
        return self._is_pyz

    def parse_args(self, opts, args):
        """parse_args.
            Add more switches here with process logic
        """

        print(f"[{datetime.now()}] [Pre-Initialization] Processing Command-line options: Start.....")
        print(f"Opts: {opts}")
        print(f"Args: {args}")

        for o, a in opts:
            if o in "--help":
                self.usage()
                sys.exit()
            elif o in "--env":
                self.env_override = a
            elif o in "--extract":
                __key = re.sub(r"^--", "", o) 
                __value = a.strip()
                self.cli_application_parameters[__key] = __value
                del __key
                del __value
            else:
                print(f">> Option: {o} - Value: {a}")
                __key = re.sub(r"^--", "", o) 
                __value = a.strip()
                self.cli_application_parameters[__key] = __value
                del __key
                del __value
            # Add command line arguments parsing options logic here here!

            # [TOML Config] Read TOML Config based on Env Look-Up or override --env [local|dev|qa|uat|prod]
        print(f"[{datetime.now()}] [Pre-Initialization] Processing Command-line options: Done!")
    
    def get_cli_application_parameters(self) -> dict:
        return self.cli_application_parameters
    
    def set_app_config(self):
        # TOML Config
        print(f"[{datetime.now()}] [Pre-Initialization] Processing TOML config: Start.....")
        app_env = os.environ.get('APP_ENVIRONMENT', 'local').lower()        
        app_env = app_env.replace("\"","").lower()
        
        if app_env in self._env_lookup:
            self._toml_config = f"{app_env}.toml"
        else:
            self._toml_config = "local.toml"

        # [TOML Config] [2] Then Use Override to update the TOML Config file
        if self.env_override is not None:

            if self.env_override in self._env_lookup:
                self._toml_config = f"{self.env_override}.toml"
            elif self.env_override == "local":
                self._toml_config = "local.toml"
            else:
                raise AttributeError(f"Invalid Env Override provided: {self.env_override}")
        print( self.env_override)
        print(f"---------{self._toml_config}---------")
        # [TOML Config] Load TOML Config and Parse the data into Object
        logging.info(f"[{datetime.now()}] [Pre-Initialization] TOML Config: {self._toml_config}")

        # Defaults to Local run or py file run
        abs_toml_config_path = os.path.abspath(
            os.path.join(os.path.dirname(self._root_package_obj), "config", self._toml_config))
        logging.info(f"[{datetime.now()}] [Pre-Initialization] Absolute TOML Config Path: {abs_toml_config_path}")

        # Identify the directory delimiter
        system_directory_delimiter = "/"
        if re.search("windows", platform.system(), re.IGNORECASE):
            system_directory_delimiter = "\\"
        logging.info(f"File System Delimiter: {system_directory_delimiter}")

        # Load Config from ZipApp package
        if self._is_pyz:
            logging.info(f"[{datetime.now()}] [Pre-Initialization] [ZipApp] Attempting to load TOML Config from package")
            config_str = pkg_resources.resource_stream(self._root_file_obj,
                                                       f'config/{self._toml_config}').read().decode()
            self._app_config = toml.loads(config_str)

            self._lconfig = yaml.safe_load(
                pkg_resources.resource_stream(
                    self._root_file_obj
                    , self._app_config.get("logging").get("log_config")
                ).read().decode()
            )
        else:
            logging.info(f"[{datetime.now()}] [Pre-Initialization] TOML Config: \n{abs_toml_config_path}")
            # Check File Exists
            if not Pth(abs_toml_config_path).is_file():
                logging.error(f"File does not exist or PATH is incorrect: {abs_toml_config_path}")
                sys.exit(255)
            logging.info(
                f"[{datetime.now()}] [Pre-Initialization] [__main__] Attempting to load TOML Config from directory")
            self._app_config = toml.load(abs_toml_config_path)
            # Import Log Configuration YAML file
            with open(self._app_config.get("logging").get("log_config"), 'r') as stream:
                self._lconfig = yaml.load(
                    stream,
                    Loader=yaml.FullLoader
                )
        logging.info(f"App Config: {self._app_config}")
        logging.info(f"[{datetime.now()}] [Pre-Initialization] Successfully loaded TOML Config")
        
        logging.config.dictConfig(self._lconfig)
        
    def getlogger(self):
        return logging.getLogger()

    def get_logging_config(self):
        return self._lconfig

    def get_app_config(self):
        return self._app_config
            
    def usage(self) -> None:
        """Usage.
        :description: Helper command
        :return:
        """
        print("""
        App.pyz --some options (UPDATE THIS FOR YOUR APP!)
        Examples:
            $> python App.pyz --some options
        """)

from datetime import time
import logging
import snowflake.connector


class Snow:
    """Snowflake Connector class
    """
    conn: snowflake.connector.connect

    def __init__(
            self,
            account: str,
            user: str,
            warehouse: str,
            role: str,
            dbname: str,
            pwd: str,
            schema: str,
            pwd_encrypted: bool = False
        ):
            """_summary_
            """
            logging.info("[Snow][Init] Initializing connection: .....")
            self.connect(
                user=user,
                pwd=pwd,
                account=account,
                role=role,
                warehouse=warehouse,
                dbname=dbname,
                schema=schema,
                pwd_encrypted=pwd_encrypted
            )
            logging.info("[Snow][Init] Initializing connection: Done!")

    def connect(
            self,
            account: str,
            user: str,
            warehouse: str,
            role: str,
            dbname: str,
            pwd: str,
            schema: str,
            pwd_encrypted: bool = False 
    ) -> None:
        """Snowflake Connection"""
        logging.info(f"[Snow][Connect] user={user}")
        logging.info(f"[Snow][Connect] password={pwd}")
        logging.info(f"[Snow][Connect] pwd_encrypted={pwd_encrypted}")
        logging.info(f"[Snow][Connect] account={account}")
        logging.info(f"[Snow][Connect] role={role}")
        logging.info(f"[Snow][Connect] warehouse={warehouse}")
        logging.info(f"[Snow][Connect] database={dbname}")
        logging.info(f"[Snow][Connect] schema={schema}")
        self.conn = snowflake.connector.connect(
            user=user,
            password=pwd,
            account=account,
            role=role,
            warehouse=warehouse,
            database=dbname,
            schema=schema
        )

    def run_query(self, query: str, params: dict = None):
        """_summary_
        Run Query with Parameters and return results

        Args:
            query (_str_): Main Query string
            params (_dict_): Query parameters dictionary
        """
        curs = self.conn.cursor()
        if params:
             curs.execute(query, params)
        else:
            curs.execute(query)
        __query_id = curs.sfqid
        logging.info(f"[Snow][Run] Query ID: {__query_id}: .....")
        while self.conn.is_still_running(self.conn.get_query_status(__query_id)):
            time.sleep(1)
        
        return curs

    def get(self, query: str, params: dict = None) -> any:
        """_summary_
        Run Query and get data from snowflake

        Args:
            query (_type_): _description_
        """
        curs = self.run_query(query = query, params = params)
        __query_id = curs.sfqid
        logging.info(f"[Snow][Run] Query ID: {__query_id}: Done!")
        curs.get_results_from_sfqid(__query_id)
        return curs.fetchall()

    def exec(self, query: str, params: dict = None) -> None:
        """_summary_
        Run Query but no output is returned

        Args:
            query (_type_): _description_
        """
        curs = self.run_query(query = query, params = params)
        __query_id = curs.sfqid
        logging.info(f"[Snow][Run] Query ID: {__query_id}: Done!")
        curs.get_results_from_sfqid(__query_id)

    def validate_extract(self, extract_name: str) -> None:
        """validate_extract.
        Validate: Go and check if the the extract name is valid and verify all the param
        If success: pass
        else: raise exception AttributeError
        params:
            :extract_name: str
        """
        pass

    def run_extract(self, extract_name: str, datasource) -> dict:
        self.validate_extract(extract_name=extract_name)
        self.export_extract(datasource)

    def export_extract(self, datasource):
        """Exports the fetched extract in required format to destination location"""
        pass



import logging
import boto3 
import os
import datetime

class MackayS3:
    
    con_s3 : boto3.client

    def __init__(self,
            acceskeyid: str,
            accesskey: str,) -> None:
        logging.info("[Amazon S3][Init] Initializing connection: .....")
        self.acceskeyid = acceskeyid
        self.accesskey = accesskey 
        logging.info("[Amazon S3][Init] Initializing connection: Done!")
     
    def s3_upload(aws_config,
                  upload_file_path,
                  upload_file_name, 
                  bucket_path,
                  use_partitions,
                  business_date
                  ):
        access_key_id = aws_config["AccessKeyID"]
        secret_access_key = aws_config["AccessKey"]
        
        if bucket_path.startswith("/"):
            bucket_path = bucket_path[1:]
        
        bucket_name, subfolder = bucket_path.split('/',1)
        print(f"Bucket name id: {bucket_name}") 
        

        if use_partitions.lower() == "true":
            businessdate = datetime.datetime.strptime(business_date,"%Y-%m-%d")
            folder_partition= "year={}/month={:02d}/day={:02d}/".format(businessdate.year,businessdate.month,businessdate.day)
            object_key = f"{folder_partition}{upload_file_name}"
        else:
            print(f"AWS subfolder : {subfolder}")
            if subfolder.endswith("/"):
                object_key = f"{subfolder}{upload_file_name}"
            else:
                object_key = f"{subfolder}/{upload_file_name}"

        print("AWS object_key: {}".format(object_key))
        
        s3 = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_access_key)
        if os.path.isfile(upload_file_path):
            print("File exists at the given path.")
        else:
            print("File does not exist at the given path.")
        s3.upload_file(upload_file_path,bucket_name,object_key)
import zipapp
import os
import shutil
import logging
import traceback
import sys
import subprocess
import toml
import re
from datetime import datetime   



# --------------------------------------------------------------------
# Default Variables for ZipApp Build
# --------------------------------------------------------------------
program_name = os.path.basename(__file__)
version = "0.0.0"
formatter = logging.Formatter(
    '[%(asctime)s] [%(filename)s] [%(levelname)s] [%(lineno)d:%(funcName)s] >> %(message)s'
)
lg = logging.getLogger(__file__)
ch = logging.StreamHandler()
ch.setFormatter(formatter)
lg.addHandler(ch)
lg.setLevel(logging.DEBUG)
zipapp_config = None
ffi_packages = []

try:
    # Read pyproject.toml to get the project info
    with open("pyproject.toml", "r") as f:
        py_project_toml = toml.load(f)
        program_name = py_project_toml["tool"]["poetry"]["name"]
        version = datetime.now().strftime("%Y.%m.%d.%H%M%S")
        if program_name is None:
            raise AttributeError("Unable to find project name in pyproject.toml")
        if version is None:
            raise AttributeError("Unable to find version in pyproject.toml")
        if "build-zipapp" in py_project_toml:
            zipapp_config = py_project_toml["build-zipapp"]
            lg.info(f"[Build] ZipApp Exclude Packages: {zipapp_config}")
        if zipapp_config and "ffi_packages" in zipapp_config:
            ffi_packages = zipapp_config["ffi_packages"]
            lg.info(f"[Build] ZipApp Config: {ffi_packages}")
        
except AttributeError:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error("Unknown AttributeError or Error occurred while reading pyproject.toml!")
    lg.error(f"Exception Type: {str(exc_type)}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)
except Exception:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error("Unknown Exception or Error occurred while reading pyproject.toml!")
    lg.error(f"Exception Type: {str(exc_type)}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)

project_name = str(os.path.basename(os.getcwd())).replace(" ", "-")
app_name = f"{project_name}-{version}.pyz"

# --------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------
build_directory = 'build'
base_dist_directory = "dist"
base_tests_directory = "tests"
base_source_directory = program_name.replace("-", "_")
lst_other_files = ["pyproject.toml", "LICENSE.txt", "README.md"]

lg.info("# =======================================================================================")
lg.info(f"# Starting Zipapp: {program_name}")
lg.info(f"# Version: {version}")
lg.info("# =======================================================================================")

# --------------------------------------------------------------------
# Zipapps build code
# --------------------------------------------------------------------
try:
    target_directory_name = base_dist_directory
    source_directory_name = base_source_directory
    tests_directory_name = base_tests_directory

    source_directory = os.path.join(os.path.dirname(os.path.realpath(__file__)), source_directory_name)
    tests_source_directory = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        source_directory_name,
        tests_directory_name
    )
    target_directory = os.path.join(os.path.dirname(os.path.realpath(__file__)), target_directory_name)
    lg.info(f"BASE: {source_directory}")
    if not os.path.exists(source_directory):
        raise NotADirectoryError("Source directory does not exists: " + str(source_directory))
    if os.path.exists(target_directory):
        shutil.rmtree(target_directory)

    os.makedirs(target_directory)
    lg.info(f"Target Path: {target_directory}")
    lg.info(f"App Name: {app_name}")
    
    # sys.exit(255)

    # Clean build Directory and Recreate
    if os.path.isdir(build_directory):
        shutil.rmtree(build_directory)
    os.makedirs(build_directory)
    venv_build_directory = build_directory

    # Release unpacked version
    release_unpacked_dist_directory = os.path.join(base_dist_directory, "releases", "unpacked")
    os.makedirs(release_unpacked_dist_directory, exist_ok=True)
    # Full Pack minus any C Library dependencies in zipapp-version
    release_fat_pack_dist_directory = os.path.join(base_dist_directory, "releases", "zipapp-fatpack")
    os.makedirs(release_fat_pack_dist_directory, exist_ok=True)
    # Minimal Package no Dependencies in zipapp-version-mini
    release_mini_dist_directory = os.path.join(base_dist_directory, "releases", "zipapp-mini")
    os.makedirs(release_mini_dist_directory, exist_ok=True)

    # Install Local Requirements
    temp_src_dir = os.getcwd()
    
    # Add PyTest at the end of the array
    # 'poetry run pytest --quiet --verbose',
    poetry_zipapp_commands = [
        # f'cd {build_directory}',
        'python -c "import os; print(os.getcwd())"',
        'python -c "import sys;print(sys.executable)"',
        'poetry lock --verbose',
        # 'poetry install --compile --verbose --without test,docs',
        'poetry install --compile --verbose',
        # 'poetry install --without test,docs',
        'poetry show --verbose',
        
    ]
    
    for comm in poetry_zipapp_commands:
        lg.info(f"Command: {comm}")
        p = subprocess.run(
            comm,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        lg.info(f"Return Code: {p.returncode}")
        if p.returncode != 0:
            lg.error(f"[STDERR] {p.stderr}")
            lg.error(f"Return Code: {p.returncode}")
            # Check PyTest No Tests found
            if p.returncode == 5 and "pytest" in comm:
                lg.info(f"PyTest Command Command: {comm}")
            else:
                raise RuntimeError(
                    f"[Error] Command error, Build failed, Requirement "
                    f"not installed! Command: {comm}")
        lg.info(f"[STDOUT] {p.stdout}")

    venv_dir = os.path.abspath(os.path.join(os.getcwd(), ".venv", "Lib", "site-packages"))
    lg.info(f"VENV: {venv_dir}")
    
    # Copy Source from src to build_directory
    lg.info(f"Copying Source to Build Directory: {source_directory_name} -> {build_directory}")
    shutil.copytree(base_source_directory, build_directory, dirs_exist_ok=True)
    shutil.copytree(base_source_directory, release_mini_dist_directory, dirs_exist_ok=True)

    for file in lst_other_files:
        shutil.copy(file, venv_build_directory)
        shutil.copy(file, release_mini_dist_directory)

    # Mini Pack
    zipapp.create_archive(
        build_directory,
        target=os.path.join(release_mini_dist_directory, app_name),
        compressed=True
    )

    # Copy Env Libraries for Fat-Pack
    shutil.copytree(venv_dir, venv_build_directory, dirs_exist_ok=True)

    # UnPacked Version
    shutil.copytree(venv_build_directory, release_unpacked_dist_directory, dirs_exist_ok=True)

    # Mini Pack 2
    shutil.copytree(venv_dir, release_mini_dist_directory, dirs_exist_ok=True)

    # Exclude Lib In ZipApp
    for obj in os.listdir(build_directory):
        for match in ffi_packages:
            if re.match(match, obj):
                match_obj_path = os.path.join(build_directory, obj)
                move_zipapp_exclude_directory = os.path.join(release_fat_pack_dist_directory, obj)
                if os.path.isdir(match_obj_path):
                    lg.info(f"[Dir] Moving Zip App Exclude File/Directory:{obj} => {match_obj_path}")
                    shutil.copytree(match_obj_path, move_zipapp_exclude_directory, dirs_exist_ok=True)
                    shutil.rmtree(match_obj_path)

                if os.path.isfile(match_obj_path):
                    lg.info(f"[File] Moving Zip App Exclude File/Directory:{obj} => {match_obj_path}")
                    shutil.copyfile(match_obj_path, move_zipapp_exclude_directory)
                    os.remove(match_obj_path)
    abs_app_path = os.path.join(release_fat_pack_dist_directory, app_name)
    lg.info(f"Abs Path: {abs_app_path}")
    zipapp.create_archive(
        build_directory,
        target=abs_app_path,
        compressed=True
    )

    if os.path.isdir(build_directory):
        shutil.rmtree(build_directory)
except subprocess.CalledProcessError:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error(f"Unknown Exception or Error occurred: {str(exc_type)}")
    lg.error(f"Exception Type: {exc_type}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)
except FileNotFoundError:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error(f"Unknown Exception or Error occurred: {str(exc_type)}")
    lg.error(f"Exception Type: {exc_type}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)
except NotADirectoryError:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error(f"Unknown NotADirectoryError occurred: f{str(exc_type)}")
    lg.error(f"Exception Type: {exc_type}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)
except Exception:
    exc_type, exc_value, exec_traceback = sys.exc_info()
    lg.error("Unknown Exception or Error occurred!")
    lg.error(f"Exception Type: {str(exc_type)}")
    lg.error(f"Exception Value: {exc_value}")
    lg.error(str.join("", traceback.format_exception(exc_type, exc_value, exec_traceback)))
    sys.exit(255)
lg.info(f"Zipapp package build successful: {app_name} [Full Path: {abs_app_path}]")
lg.info("Shutting down build process!")

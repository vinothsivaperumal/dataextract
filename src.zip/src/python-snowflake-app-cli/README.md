# Introduction 
Python Extraction engine: TBD!

# Build and Test
To build application to distribute
## ZipApp
```
python build.py
```
### How to run the ZipApp
```
TBD
```


# Usage
- Run With Extract Name (with default output formt from Config Table)
```
python app.py --extract-name HY_HPX_ANALYTICS
```
    - Export to specific directory
    ```
    python app.py --extract-name HY_HPX_ANALYTICS --output-directory c:/Temp
    ```
- Run Extract with Format (Override format)
    - Excels
    ```
    python app.py --extract-name HY_HPX_ANALYTICS --output-format XLS
    ```
    - PDF
    ```
    python app.py --extract-name HY_HPX_ANALYTICS --output-format PDF
    ```

- Run Extract for Historical Date (YYYY-MM-DD) for Specific date
    - No Override Output Format
        - Using Param yyyymmdd (will be used to replace param in query AS_OF_DATE ${YYYY-MM-DD} param:
        ```
        python app.py --extract-name HY_HPX_ANALYTICS --yyyymmdd 20240229
        ```
        - Using business-date (will be used to replace param in query $BUSINESS_DATE) Param:
        ```
        python app.py --extract-name HY_HPX_ANALYTICS --business-date 20240229
        ```
    - with output override example PDF:
    ```
    python app.py --extract-name HY_HPX_ANALYTICS --yyyymmdd 20240229 --output-format PDF
    ```

- Run with Output file name override
```
python app.py --extract-name HY_HPX_ANALYTICS --output-format PDF --output-filename MACKAY-MANUAL-REPORT-2024-05-03
```
# Contribute
TBD